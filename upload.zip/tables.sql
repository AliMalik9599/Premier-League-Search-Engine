Ctrl-C -- exit!
